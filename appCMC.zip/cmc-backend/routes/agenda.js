import express from 'express';
import { wordpressAPI } from '../config/wordpress.js';
import pool from '../db.js';
import { authRequired } from '../utils/authMiddleware.js';

const router = express.Router();

// ============================================================
// HELPERS
// ============================================================

/** Convierte hora "HH:MM" a timestamp ISO para la DB */
function convertirHoraATimestamp(hora) {
  if (!hora) return null;
  try {
    if (hora.includes('T') && hora.includes('Z')) return hora;
    const [h, m, s] = hora.split(':').map(Number);
    if (isNaN(h) || isNaN(m)) return null;
    const now = new Date();
    now.setHours(h, m, s || 0, 0);
    return now.toISOString();
  } catch {
    return null;
  }
}

/** Resuelve wp_id numérico → UUID interno del speaker */
async function getUUIDFromWpId(wpSpeakerId) {
  if (!wpSpeakerId) return null;
  try {
    const result = await pool.query(
      'SELECT id FROM speakers WHERE wp_id = $1 LIMIT 1',
      [wpSpeakerId]
    );
    return result.rows[0]?.id ?? null;
  } catch {
    return null;
  }
}

/** Normaliza el campo día a entero (1=lunes … 5=viernes) */
function normalizarDia(dia) {
  if (dia === null || dia === undefined) return null;
  if (typeof dia === 'number') return dia;
  const map = { lunes: 1, martes: 2, miercoles: 3, miércoles: 3, jueves: 4, viernes: 5 };
  return map[dia.toString().toLowerCase().trim()] ?? null;
}

/** Extrae sede, tipo, edición y categoría desde el class_list de WordPress */
function parseSessionClassList(classList = []) {
  let sede = null, tipo = null, edicion = null, categoria = 'sesion';

  classList.forEach((cls) => {
    if (cls === 'events_category-chile')    sede = 'chile';
    if (cls === 'events_category-mexico')   sede = 'mexico';
    if (cls === 'events_category-colombia') sede = 'colombia';

    if (cls.startsWith('events_category-') && /\d{4}/.test(cls)) {
      const tipoMatch = cls.match(/events_category-(brujula|toolbox|spark|orion|tracker|cursos)-/i);
      if (tipoMatch) {
        tipo = tipoMatch[1].toLowerCase();
        if (tipo === 'cursos') categoria = 'curso';
      }
      const paisMatch = cls.match(/-(cl|mx|co)-/i);
      if (paisMatch) {
        const p = paisMatch[1].toLowerCase();
        sede = p === 'cl' ? 'chile' : p === 'mx' ? 'mexico' : 'colombia';
      }
      const yearMatch = cls.match(/(\d{4})/);
      if (yearMatch) edicion = parseInt(yearMatch[1]);
    }
  });

  return { sede, tipo, edicion, categoria };
}

// ============================================================
// Carga sesiones locales desde la DB (usada sola o como fallback)
// ============================================================
async function cargarSesionesLocales(sede, edicion) {
  // Overrides de sesiones de WordPress
  const overridesResult = await pool.query(`
    SELECT
      wp_id,
      title           AS titulo,
      description     AS descripcion,
      dia,
      start_at        AS "horaInicio",
      end_at          AS "horaFin",
      sala, room, tipo, categoria,
      sede,
      COALESCE(sede_override, sede)       AS sede_final,
      edicion,
      COALESCE(year_override, year, edicion) AS edicion_final,
      speakers,
      qr_sala         AS "qrSala",
      wp_slug         AS slug,
      activo, destacado, override
    FROM agenda
    WHERE wp_id IS NOT NULL AND override = true AND activo = true
  `);

  const overridesMap = {};
  overridesResult.rows.forEach((o) => {
    overridesMap[o.wp_id] = {
      id: o.wp_id,
      wp_id: o.wp_id,
      titulo: o.titulo,
      descripcion: o.descripcion,
      dia: o.dia,
      horaInicio: o.horaInicio,
      horaFin: o.horaFin,
      sala: o.sala || o.room,
      tipo: o.tipo,
      categoria: o.categoria,
      sede: o.sede_final || o.sede,
      edicion: o.edicion_final || o.edicion,
      speakerId: o.speakers?.[0] ?? null,
      speakerNombre: '',
      qrSala: o.qrSala,
      slug: o.slug,
      source: 'wordpress-edited',
      canEdit: true,
      destacado: o.destacado,
      isOverride: true,
    };
  });

  // Sesiones 100% locales (creadas en el panel)
  const localResult = await pool.query(`
    SELECT
      id,
      title           AS titulo,
      description     AS descripcion,
      dia,
      start_at        AS "horaInicio",
      end_at          AS "horaFin",
      sala, room, tipo, categoria,
      sede,
      COALESCE(sede_override, sede)          AS sede_final,
      edicion,
      COALESCE(year_override, year, edicion) AS edicion_final,
      speakers,
      qr_sala         AS "qrSala",
      wp_slug         AS slug,
      activo, destacado
    FROM agenda
    WHERE wp_id IS NULL AND activo = true
    ORDER BY start_at ASC NULLS LAST
  `);

  const localSessions = localResult.rows.map((s) => ({
    id: s.id,
    titulo: s.titulo,
    descripcion: s.descripcion,
    dia: s.dia,
    horaInicio: s.horaInicio,
    horaFin: s.horaFin,
    sala: s.sala || s.room,
    tipo: s.tipo,
    categoria: s.categoria,
    sede: s.sede_final || s.sede,
    edicion: s.edicion_final || s.edicion,
    speakerId: s.speakers?.[0] ?? null,
    speakerNombre: '',
    qrSala: s.qrSala,
    slug: s.slug,
    source: 'local',
    canEdit: true,
    destacado: s.destacado,
    isOverride: false,
  }));

  // Combinar overrides + locales y aplicar filtros
  let sessions = [...Object.values(overridesMap), ...localSessions];

  if (sede) {
    sessions = sessions.filter((s) => s.sede === sede.toLowerCase());
  }
  if (edicion) {
    sessions = sessions.filter((s) => s.edicion === parseInt(edicion));
  }

  return { sessions, overridesMap };
}

// ============================================================
// GET /sessions
// ============================================================
router.get('/sessions', authRequired, async (req, res) => {
  const { sede, edicion } = req.query;

  console.log(`[Agenda] GET /sessions — sede=${sede}, edicion=${edicion}`);

  let wpSessions = [];
  let wpTotal = 0;
  let wpError = null;

  // ── Intentar cargar desde WordPress ──────────────────────
  try {
    const wpResponse = await wordpressAPI.get('/session', {
      params: { per_page: 100, _fields: 'id,title,content,slug,class_list,acf' },
      timeout: 5000, // 5 s máximo — si WP tarda más, usamos fallback local
    });

    wpTotal = wpResponse.data.length;
    console.log(`[Agenda] WordPress: ${wpTotal} sesiones`);

    // Cargar overrides para aplicar encima de los datos de WP
    const { overridesMap } = await cargarSesionesLocales(null, null);

    wpSessions = wpResponse.data.map((post) => {
      if (overridesMap[post.id]) return overridesMap[post.id];

      const parsed = parseSessionClassList(post.class_list || []);
      return {
        id: post.id,
        wp_id: post.id,
        titulo: post.title?.rendered || '',
        descripcion: post.content?.rendered?.replace(/<[^>]+>/g, '').substring(0, 200) || '',
        slug: post.slug,
        dia: post.acf?.dia ?? 0,
        horaInicio: post.acf?.hora_inicio || post.acf?.start_time || null,
        horaFin: post.acf?.hora_fin   || post.acf?.end_time   || null,
        sala: post.acf?.sala || post.acf?.room || '',
        qrSala: post.acf?.qr_sala || post.acf?.qr || '',
        tipo: parsed.tipo || 'general',
        categoria: parsed.categoria,
        sede: parsed.sede,
        edicion: parsed.edicion,
        speakerNombre: post.acf?.speaker    || '',
        speakerId:     post.acf?.speaker_id || null,
        source: 'wordpress',
        canEdit: true,
        isOverride: false,
      };
    });

    // Aplicar filtros a sesiones de WP
    if (sede)    wpSessions = wpSessions.filter((s) => s.sede    === sede.toLowerCase());
    if (edicion) wpSessions = wpSessions.filter((s) => s.edicion === parseInt(edicion));

  } catch (err) {
    wpError = err.message;
    console.warn(`[Agenda] ⚠️ WordPress no disponible: ${wpError}`);
    console.warn('[Agenda] Usando solo sesiones locales como fallback');
  }

  // ── Cargar sesiones locales (siempre) ────────────────────
  const { sessions: localSessions } = await cargarSesionesLocales(sede, edicion);

  // Si WP falló, localSessions ya incluye los overrides
  // Si WP funcionó, localSessions solo tiene las sesiones locales puras (wp_id IS NULL)
  // — para no duplicar overrides que ya se aplicaron arriba
  let localOnly = localSessions;
  if (!wpError) {
    localOnly = localSessions.filter((s) => s.source === 'local');
  }

  const allSessions = [...wpSessions, ...localOnly];

  console.log(`[Agenda] Total final: ${allSessions.length} sesiones (WP: ${wpSessions.length}, local: ${localOnly.length})`);

  res.json({
    sessions: allSessions,
    total: allSessions.length,
    sources: {
      wordpress: wpSessions.length,
      local: localOnly.length,
      overrides: wpSessions.filter((s) => s.isOverride).length,
    },
    ...(wpError && {
      warning: 'WordPress no disponible. Mostrando solo sesiones locales.',
      wpError,
    }),
  });
});

// ============================================================
// POST /sessions — Crear sesión local
// ============================================================
router.post('/sessions', authRequired, async (req, res) => {
  try {
    const { titulo, descripcion, dia, horaInicio, horaFin, sala, tipo, sede, edicion, speakerId } = req.body;

    if (!titulo || !tipo || !sede || !edicion) {
      return res.status(400).json({ error: 'Campos requeridos: titulo, tipo, sede, edicion' });
    }

    let speakersArray = null;
    if (speakerId) {
      const uuid = await getUUIDFromWpId(speakerId);
      speakersArray = uuid ? [uuid] : null;
    }

    const result = await pool.query(
      `INSERT INTO agenda
        (id, title, description, dia, start_at, end_at, sala, tipo, sede, edicion, year,
         speakers, categoria, activo, source, override, created_at)
       VALUES
        (gen_random_uuid(), $1, $2, $3, $4, $5, $6, $7, $8, $9, $9, $10, $11, true, 'local', false, NOW())
       RETURNING
        id,
        title       AS titulo,
        description AS descripcion,
        dia,
        start_at    AS "horaInicio",
        end_at      AS "horaFin",
        sala, tipo, sede, edicion, speakers, categoria`,
      [titulo, descripcion || '', dia || null, horaInicio || null, horaFin || null,
       sala || '', tipo, sede, edicion, speakersArray, tipo === 'curso' ? 'curso' : 'sesion']
    );

    console.log('[Agenda] ✅ Sesión creada:', result.rows[0].id);
    res.status(201).json({ ok: true, session: result.rows[0], message: 'Sesión creada exitosamente' });

  } catch (err) {
    console.error('❌ Error creando sesión:', err);
    res.status(500).json({ ok: false, error: 'Error creando sesión', details: err.message });
  }
});

// ============================================================
// PUT /sessions/:id — Actualizar sesión (WP override o local)
// ============================================================
router.put('/sessions/:id', authRequired, async (req, res) => {
  try {
    const { id } = req.params;
    const { titulo, descripcion, horaInicio, horaFin, sala, tipo, sede, edicion, speakerId } = req.body;

    const diaFinal = (() => {
      const d = normalizarDia(req.body.dia);
      if (typeof d === 'number') return d;
      if (req.body.dia) console.warn('[Agenda] ⚠️ Día inválido recibido:', req.body.dia);
      return null;
    })();

    let speakersArray = null;
    if (speakerId) {
      const uuid = await getUUIDFromWpId(speakerId);
      speakersArray = uuid ? [uuid] : null;
    }

    // CASO 1: Sesión de WordPress (ID numérico grande)
    if (!isNaN(id) && parseInt(id) > 1000) {
      const startTs = convertirHoraATimestamp(horaInicio);
      const endTs   = convertirHoraATimestamp(horaFin);
      const wpId    = parseInt(id);

      const existing = await pool.query(
        'SELECT id FROM agenda WHERE wp_id = $1 AND override = true', [wpId]
      );

      if (existing.rows.length > 0) {
        // Actualizar override existente
        const result = await pool.query(
          `UPDATE agenda SET
            title         = COALESCE($1,  title),
            description   = COALESCE($2,  description),
            dia           = COALESCE($3,  dia),
            start_at      = COALESCE($4,  start_at),
            end_at        = COALESCE($5,  end_at),
            sala          = COALESCE($6,  sala),
            tipo          = COALESCE($7,  tipo),
            sede_override = COALESCE($8,  sede_override),
            year_override = COALESCE($9,  year_override),
            speakers      = COALESCE($10, speakers)
           WHERE wp_id = $11 AND override = true
           RETURNING wp_id AS id, title AS titulo, description AS descripcion,
                     dia, start_at AS "horaInicio", end_at AS "horaFin", sala, tipo`,
          [titulo, descripcion, diaFinal, startTs, endTs, sala, tipo, sede, edicion, speakersArray, wpId]
        );
        return res.json({ ok: true, session: result.rows[0], message: 'Sesión actualizada (override)' });

      } else {
        // Crear nuevo override
        await pool.query(
          `INSERT INTO agenda
            (id, wp_id, title, description, dia, start_at, end_at, sala, tipo,
             sede, sede_override, edicion, year, year_override, speakers,
             categoria, activo, source, override, created_at)
           VALUES
            (gen_random_uuid(), $1, $2, $3, $4, $5, $6, $7, $8, $9, $9, $10, $10, $10,
             $11, $12, true, 'wordpress', true, NOW())`,
          [wpId, titulo, descripcion || '', diaFinal,
           convertirHoraATimestamp(horaInicio), convertirHoraATimestamp(horaFin),
           sala || '', tipo, sede, edicion, speakersArray, tipo === 'curso' ? 'curso' : 'sesion']
        );
        return res.json({ ok: true, session: { id: wpId, titulo }, message: 'Override creado para sesión de WordPress' });
      }
    }

    // CASO 2: Sesión local (UUID)
    const check = await pool.query('SELECT id FROM agenda WHERE id = $1', [id]);
    if (check.rows.length === 0) {
      return res.status(404).json({ ok: false, error: 'Sesión no encontrada' });
    }

    const result = await pool.query(
      `UPDATE agenda SET
        title       = COALESCE($1,  title),
        description = COALESCE($2,  description),
        dia         = COALESCE($3,  dia),
        start_at    = COALESCE($4,  start_at),
        end_at      = COALESCE($5,  end_at),
        sala        = COALESCE($6,  sala),
        tipo        = COALESCE($7,  tipo),
        sede        = COALESCE($8,  sede),
        edicion     = COALESCE($9,  edicion),
        year        = COALESCE($9,  year),
        speakers    = COALESCE($10, speakers)
       WHERE id = $11
       RETURNING id, title AS titulo, description AS descripcion,
                 dia, start_at AS "horaInicio", end_at AS "horaFin",
                 sala, tipo, sede, edicion`,
      [titulo, descripcion, diaFinal,
       convertirHoraATimestamp(horaInicio), convertirHoraATimestamp(horaFin),
       sala, tipo, sede, edicion, speakersArray, id]
    );

    console.log('[Agenda] ✅ Sesión local actualizada:', id);
    res.json({ ok: true, session: result.rows[0], message: 'Sesión actualizada exitosamente' });

  } catch (err) {
    console.error('❌ Error actualizando sesión:', err);
    res.status(500).json({ ok: false, error: 'Error actualizando sesión', details: err.message });
  }
});

// ============================================================
// DELETE /sessions/:id — Eliminar sesión
// ============================================================
router.delete('/sessions/:id', authRequired, async (req, res) => {
  try {
    const { id } = req.params;

    if (!isNaN(id) && parseInt(id) > 1000) {
      await pool.query(
        'UPDATE agenda SET activo = false WHERE wp_id = $1 AND override = true',
        [parseInt(id)]
      );
      return res.json({ ok: true, message: 'Override eliminado. La sesión volverá a mostrar datos de WordPress' });
    }

    const check = await pool.query('SELECT id FROM agenda WHERE id = $1', [id]);
    if (check.rows.length === 0) {
      return res.status(404).json({ ok: false, error: 'Sesión no encontrada' });
    }

    await pool.query('UPDATE agenda SET activo = false WHERE id = $1', [id]);

    console.log('[Agenda] ✅ Sesión eliminada:', id);
    res.json({ ok: true, message: 'Sesión eliminada exitosamente' });

  } catch (err) {
    console.error('❌ Error eliminando sesión:', err);
    res.status(500).json({ ok: false, error: 'Error eliminando sesión', details: err.message });
  }
});

// ============================================================
// POST /favorite/:id — Agregar a favoritos
// ============================================================
router.post('/favorite/:id', authRequired, async (req, res) => {
  try {
    await pool.query(
      `INSERT INTO favoritos (user_id, session_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
      [req.user.id, req.params.id]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('❌ Error guardando favorito:', err);
    res.status(500).json({ error: 'Error al guardar favorito' });
  }
});

// ============================================================
// DELETE /favorite/:id — Quitar de favoritos
// ============================================================
router.delete('/favorite/:id', authRequired, async (req, res) => {
  try {
    await pool.query(
      `DELETE FROM favoritos WHERE user_id = $1 AND session_id = $2`,
      [req.user.id, req.params.id]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('❌ Error quitando favorito:', err);
    res.status(500).json({ error: 'Error al quitar favorito' });
  }
});

// ============================================================
// POST /checkin — Registrar asistencia por QR
// ============================================================
router.post('/checkin', authRequired, async (req, res) => {
  try {
    const { qr, userId } = req.body;

    if (!qr || !userId) {
      return res.status(400).json({ error: 'Datos incompletos' });
    }

    const sessionResult = await pool.query(
      `SELECT id, title AS titulo FROM agenda WHERE qr_sala = $1`,
      [qr]
    );

    if (sessionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Código QR inválido' });
    }

    const session = sessionResult.rows[0];

    const exists = await pool.query(
      `SELECT 1 FROM asistencias_sesion WHERE session_id = $1 AND user_id = $2`,
      [session.id, userId]
    );

    if (exists.rows.length > 0) {
      return res.status(400).json({ error: 'Ya registraste asistencia' });
    }

    await pool.query(
      `INSERT INTO asistencias_sesion (id, session_id, user_id, fecha)
       VALUES (gen_random_uuid(), $1, $2, NOW())`,
      [session.id, userId]
    );

    res.json({ ok: true, session: { id: session.id, titulo: session.titulo } });

  } catch (err) {
    console.error('❌ Error en check-in:', err);
    res.status(500).json({ error: 'Error al registrar asistencia' });
  }
});

export default router;