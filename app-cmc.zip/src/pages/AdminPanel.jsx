// src/pages/AdminPanel.jsx
// Panel de Administración CMC — Super Admin y Staff
//
// ACCESO:
//   • super_admin → acceso total: crear, editar, eliminar todo + notificaciones
//   • staff       → puede editar speakers/expositores, ver sesiones (solo lectura en sesiones)
//
// CONDICIONADO A:
//   • Sede activa (EventContext.sedeActiva) → filtra y pre-llena sede
//   • Edición activa (EventContext.edicionActiva)
//
// TABS: Sesiones | Speakers | Expositores | Notificaciones
//
// CAMPOS ALINEADOS CON NEONDB:
//   agenda:     id, title, description, start_at, end_at, room, sala, dia,
//               tipo, categoria, sede, edicion, activo, capacidad
//   speakers:   id, nombre, bio, company, photo_url, cargo, email, telefono,
//               linkedin_url, twitter_url, website_url, sede, edicion, activo
//   expositores: id, nombre, descripcion, stand, logo_url, contact(jsonb),
//                categoria, website_url, sede, edicion, activo
//   notificaciones: titulo, mensaje, tipo, tipo_usuario(array), sede, activa

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth }  from "../contexts/AuthContext.jsx";
import { useEvent } from "../contexts/EventContext.jsx";
import API from "../services/api";
import {
  Plus, Edit2, Trash2, Save, X, Bell, Users,
  FileUp, AlertCircle, CheckCircle, Loader2,
  Calendar, Mic, Building2, ExternalLink, ChevronDown,
  RefreshCw, Wifi, WifiOff, Clock, Map,
} from "lucide-react";

// ── Sedes del sistema ─────────────────────────────────────
const SEDES = ["mexico", "chile", "colombia"];

// ── Tipos de pase (para segmentar notificaciones) ────────
const TIPOS_PASE = [
  { id: "todos",              label: "Todos" },
  { id: "asistente_general",  label: "Asistente General" },
  { id: "asistente_curso",    label: "Asistente Curso" },
  { id: "asistente_sesiones", label: "Asistente Sesiones" },
  { id: "asistente_combo",    label: "Asistente Combo" },
  { id: "expositor",          label: "Expositor" },
  { id: "speaker",            label: "Speaker" },
  { id: "staff",              label: "Staff" },
];

// ────────────────────────────────────────────────────────────
// Campo de entrada reutilizable
// ────────────────────────────────────────────────────────────
function Field({ label, children }) {
  return (
    <div className="space-y-1">
      {label && <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide">{label}</label>}
      {children}
    </div>
  );
}

const inputCls = "w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500";
const btnPrimary = "flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 font-semibold text-sm disabled:opacity-50 transition";
const btnDanger  = "flex items-center gap-2 bg-red-500 text-white px-3 py-1.5 rounded-xl hover:bg-red-600 text-sm transition";
const btnGhost   = "flex items-center gap-2 border border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 px-4 py-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 text-sm transition";

// ────────────────────────────────────────────────────────────
// COMPONENTE PRINCIPAL
// ────────────────────────────────────────────────────────────

// ════════════════════════════════════════════════════════════
const ESTADOS_STAND = {
  libre:         { label: "Libre",          bg: "#f0fdf4", border: "#86efac", text: "#16a34a", dot: "#22c55e" },
  solicitado:    { label: "Solicitado",     bg: "#fffbeb", border: "#fcd34d", text: "#d97706", dot: "#eab308" },
  ocupado:       { label: "Ocupado",        bg: "#eff6ff", border: "#93c5fd", text: "#1d4ed8", dot: "#3b82f6" },
  no_disponible: { label: "No disponible",  bg: "#f9fafb", border: "#d1d5db", text: "#6b7280", dot: "#9ca3af" },
};

// Categorías y tamaños por sede (ancho_m x alto_m → celdas en grid de 3x3m base)
const CATEGORIAS_POR_SEDE = {
  colombia: [
    { key:"diamante_plus", label:"Diamante Plus", ancho_m:6, alto_m:4, celdas_ancho:2, celdas_alto:2, color:"#7c3aed" },
    { key:"diamante",      label:"Diamante",      ancho_m:6, alto_m:4, celdas_ancho:2, celdas_alto:2, color:"#db2777" },
    { key:"esmeralda",     label:"Esmeralda",     ancho_m:6, alto_m:3, celdas_ancho:2, celdas_alto:1, color:"#059669" },
    { key:"platino",       label:"Platino",       ancho_m:6, alto_m:6, celdas_ancho:2, celdas_alto:2, color:"#ca8a04" },
    { key:"oro",           label:"Oro",           ancho_m:6, alto_m:3, celdas_ancho:2, celdas_alto:1, color:"#d97706" },
    { key:"plata",         label:"Plata",         ancho_m:3, alto_m:3, celdas_ancho:1, celdas_alto:1, color:"#64748b" },
  ],
  mexico: [
    { key:"platino", label:"Platino", ancho_m:6, alto_m:6, celdas_ancho:2, celdas_alto:2, color:"#ca8a04" },
    { key:"oro",     label:"Oro",     ancho_m:6, alto_m:3, celdas_ancho:2, celdas_alto:1, color:"#d97706" },
    { key:"plata",   label:"Plata",   ancho_m:3, alto_m:3, celdas_ancho:1, celdas_alto:1, color:"#64748b" },
  ],
  chile: [
    { key:"platino", label:"Platino", ancho_m:5, alto_m:2, celdas_ancho:2, celdas_alto:1, color:"#ca8a04" },
    { key:"oro",     label:"Oro",     ancho_m:3, alto_m:2, celdas_ancho:1, celdas_alto:1, color:"#d97706" },
    { key:"plata",   label:"Plata",   ancho_m:3, alto_m:2, celdas_ancho:1, celdas_alto:1, color:"#64748b" },
  ],
};

export default function AdminPanel() {
  const { userProfile } = useAuth();
  const { sedeActiva, edicionActiva } = useEvent();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState("sesiones");
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState(null);
  const [success, setSuccess]     = useState(null);

  // Sede usada en formularios — inicia desde la sede activa del evento
  const [sedeForm, setSedeForm] = useState(sedeActiva || "colombia");

  useEffect(() => {
    if (sedeActiva) setSedeForm(sedeActiva);
  }, [sedeActiva]);

  // ── Sesiones ────────────────────────────────────────────
  const [sessions,        setSessions]        = useState([]);
  const [eventos,         setEventos]         = useState([]);
  const [showEventoForm,  setShowEventoForm]  = useState(false);
  const [editingEventoId, setEditingEventoId] = useState(null);
  const [eventoForm,      setEventoForm]      = useState({ titulo:"", dia:1, horaInicio:"", horaFin:"", tipo:"registro", sala:"" });

  const [filtroSede,      setFiltroSede]      = useState("");
  const [sinTitulo,       setSinTitulo]       = useState([]);
  const [syncing,         setSyncing]         = useState(false);
  const [wpConfig,        setWpConfig]        = useState(null);
  const [wpStatus,        setWpStatus]        = useState(null); // null|'ok'|'error'
  const [showWpPanel,     setShowWpPanel]     = useState(false);
  const [wpForm,          setWpForm]          = useState({ wp_api_url:'', wp_username:'', wp_app_password:'' });
  const [testingWp,       setTestingWp]       = useState(false);
  const [wpTestResult,    setWpTestResult]    = useState(null);

  const [showSessionForm, setShowSessionForm] = useState(false);
  const [editingSessionId, setEditingSessionId] = useState(null);
  const [sessionForm,     setSessionForm]     = useState(blankSession(sedeForm, edicionActiva));

  function blankSession(sede, edicion) {
    return {
      title: "", description: "", start_at: "", end_at: "", speakerId: "",
      room: "", sala: "", dia: 1, tipo: "sesion", categoria: "brujula",
      sede: sede || "colombia", edicion: edicion || 2026,
      capacidad: "", activo: true,
    };
  }

  // ── Speakers ────────────────────────────────────────────
  const [speakers,        setSpeakers]        = useState([]);
  const [showSpeakerForm, setShowSpeakerForm] = useState(false);
  const [editingSpeakerId, setEditingSpeakerId] = useState(null);
  const [speakerForm,     setSpeakerForm]     = useState(blankSpeaker(sedeForm, edicionActiva));

  function blankSpeaker(sede, edicion) {
    return {
      nombre: "", bio: "", company: "", photo_url: "", cargo: "",
      email: "", telefono: "", linkedin_url: "", twitter_url: "",
      website_url: "", sede: sede || "colombia", edicion: edicion || 2026,
      activo: true,
    };
  }

  // ── Expositores ─────────────────────────────────────────
  const [expositores,        setExpositores]        = useState([]);
  const [showExpositorForm,  setShowExpositorForm]  = useState(false);
  const [editingExpositorId, setEditingExpositorId] = useState(null);
  const [expositorForm,      setExpositorForm]      = useState(blankExpositor(sedeForm, edicionActiva));

  function blankExpositor(sede, edicion) {
    return {
      nombre: "", descripcion: "", stand: "", logo_url: "",
      categoria: "", website_url: "",
      contact_email: "", contact_telefono: "", contact_nombre: "",
      sede: sede || "colombia", edicion: edicion || 2026, activo: true,
    };
  }

  // ── Notificaciones ──────────────────────────────────────
  const [showNotiForm,   setShowNotiForm]   = useState(false);
  const [notiForm,       setNotiForm]       = useState(blankNoti());
  const [users,          setUsers]          = useState([]);
  const [notiLoading,    setNotiLoading]    = useState(false);
  const [notiError,      setNotiError]      = useState(null);

  function blankNoti() {
    return {
      titulo: "", mensaje: "", tipo: "info",
      tipo_usuario: ["todos"], sede: "todos",
    };
  }

  // ────────────────────────────────────────────────────────
  // CARGA POR TAB
  // ────────────────────────────────────────────────────────
  useEffect(() => {
    if (!userProfile) return;
    if (activeTab === "sesiones")       loadSessions();
    if (activeTab === "eventos")        loadEventos();
    loadSpeakers(); // para el selector en form de sesiones
    loadWpConfig();
    loadSinTitulo();

    if (activeTab === "speakers")       loadSpeakers();
    if (activeTab === "expositores")    loadExpositores();
    if (activeTab === "mapa_stands")    loadExpositores();
    if (activeTab === "notificaciones") loadUsers();
  }, [activeTab, userProfile]);

  const flash = (msg, isError = false) => {
    if (isError) setError(msg);
    else         { setSuccess(msg); setTimeout(() => setSuccess(null), 3500); }
  };

  // ────────────────────────────────────────────────────────
  // SESIONES
  // ────────────────────────────────────────────────────────
  const loadWpConfig = async () => {
    try {
      const r = await API.get('/config/wp-config');
      setWpConfig(r.data);
      setWpForm(f => ({
        wp_api_url: r.data.wp_config?.wp_api_url || '',
        wp_username: r.data.wp_config?.wp_username || '',
        wp_app_password: '',
      }));
    } catch { /* silencioso */ }
  };

  const loadSinTitulo = async () => {
    try {
      const r = await API.get('/agenda/sessions/sin-titulo');
      setSinTitulo(r.data.sesiones || []);
    } catch { setSinTitulo([]); }
  };

  const handleSyncWp = async (forzar = false) => {
    if (!confirm(forzar
      ? '¿Re-sincronizar TODAS las sesiones desde WordPress? Esto recuperará las que quedaron sin título.'
      : '¿Sincronizar sesiones desde WordPress ahora?'
    )) return;
    setSyncing(true);
    try {
      const r = await API.post('/agenda/sessions/sync-wp', {
        sede: filtroSede || null,
        forzar_limpiar: forzar,
      });
      flash(`✅ ${r.data.message} — ${r.data.reparadas} sesiones recuperadas`);
      loadSessions();
      loadSinTitulo();
    } catch (e) {
      flash(e.response?.data?.error || 'Error al sincronizar', true);
    } finally { setSyncing(false); }
  };

  const handleTestWp = async () => {
    setTestingWp(true); setWpTestResult(null);
    try {
      const r = await API.post('/config/test-wp', wpForm);
      setWpTestResult(r.data);
    } catch { setWpTestResult({ ok: false, mensaje: 'Error de conexión' }); }
    finally { setTestingWp(false); }
  };

  const handleSaveWpConfig = async () => {
    try {
      await API.put('/config/wp-config', wpForm);
      flash('Configuración de WordPress guardada');
      setShowWpPanel(false);
      loadWpConfig();
    } catch (e) { flash(e.response?.data?.error || 'Error', true); }
  };

  const sessionsFiltradas = filtroSede
    ? sessions.filter(s => (s.sede || '').toLowerCase() === filtroSede.toLowerCase())
    : sessions;

  const loadEventos = async () => {
    try {
      const tiposL = ["registro","recepcion","expo_abierta","keynote","coffee_break","almuerzo","networking","clausura","otro"];
      const r = await API.get(`/agenda/sessions?sede=${sedeForm || sedeActiva}`);
      const all = r.data?.sessions || [];
      setEventos(all.filter(s => tiposL.includes(s.tipo) || s.categoria === "logistica"));
    } catch { setEventos([]); }
  };

  const submitEvento = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const p = {
        titulo: eventoForm.titulo, horaInicio: eventoForm.horaInicio || null,
        horaFin: eventoForm.horaFin || null, dia: parseInt(eventoForm.dia) || 1,
        tipo: eventoForm.tipo, categoria: "logistica",
        sala: eventoForm.sala, sede: sedeForm || sedeActiva,
        edicion: parseInt(edicionActiva) || 2026, activo: true,
      };
      if (editingEventoId) { await API.put(`/agenda/sessions/${editingEventoId}`, p); flash("Evento actualizado"); }
      else                 { await API.post("/agenda/sessions", p);                   flash("Evento creado"); }
      setShowEventoForm(false); setEditingEventoId(null);
      setEventoForm({ titulo:"", dia:1, horaInicio:"", horaFin:"", tipo:"registro", sala:"" });
      loadEventos();
    } catch(err) { flash(err.response?.data?.error || err.message, true); }
    finally { setLoading(false); }
  };

  const loadSessions = async () => {


    try {
      setLoading(true);
      const res = await API.get("/agenda/sessions");
      // La API devuelve { sessions: [...] }
      const list = Array.isArray(res.data.sessions)
        ? res.data.sessions
        : Array.isArray(res.data) ? res.data : [];
      setSessions(list);
    } catch (e) {
      flash("No se pudieron cargar las sesiones", true);
    } finally { setLoading(false); }
  };

  const submitSession = async (e) => {
    e.preventDefault();
    try {
      setLoading(true); setError(null);
      // FIX: el backend PUT/POST espera titulo/horaInicio/horaFin (no title/start_at/end_at)
      const payload = {
        titulo:      sessionForm.title,
        descripcion: sessionForm.description,
        horaInicio:  sessionForm.start_at || null,
        horaFin:     sessionForm.end_at   || null,
        sala:        sessionForm.sala || sessionForm.room,
        dia:         parseInt(sessionForm.dia) || 1,
        tipo:        sessionForm.tipo,
        categoria:   sessionForm.categoria,
        sede:        sessionForm.sede,
        edicion:     parseInt(sessionForm.edicion) || edicionActiva || 2026,
        capacidad:   sessionForm.capacidad ? parseInt(sessionForm.capacidad) : null,
        activo:      sessionForm.activo !== false,
        speakerId:   sessionForm.speakerId || null,
      };
      if (editingSessionId) {
        await API.put(`/agenda/sessions/${editingSessionId}`, payload);
        flash("Sesión actualizada correctamente");
      } else {
        await API.post("/agenda/sessions", payload);
        flash("Sesión creada correctamente");
      }
      resetSessionForm();
      loadSessions();
    } catch (e) {
      flash(e.response?.data?.error || e.message, true);
    } finally { setLoading(false); }
  };

  const deleteSession = async (id) => {
    if (!confirm("¿Eliminar esta sesión?")) return;
    try {
      await API.delete(`/agenda/sessions/${id}`);
      setSessions(s => s.filter(x => x.id !== id));
      flash("Sesión eliminada");
    } catch (e) { flash(e.response?.data?.error || e.message, true); }
  };

  const editSession = (s) => {
    setEditingSessionId(s.id);
    setSessionForm({
      title:       s.title       || s.titulo      || "",
      description: s.description || s.descripcion || "",
      start_at:    s.start_at    ? String(s.start_at).slice(0,16)
                 : s.horaInicio  ? String(s.horaInicio).slice(0,16) : "",
      end_at:      s.end_at      ? String(s.end_at).slice(0,16)
                 : s.horaFin     ? String(s.horaFin).slice(0,16)   : "",
      room:        s.room        || s.sala  || "",
      sala:        s.sala        || s.room  || "",
      dia:         s.dia         || s.day_number || 1,
      tipo:        s.tipo        || "sesion",
      categoria:   s.categoria   || "brujula",
      sede:        s.sede        || sedeForm,
      edicion:     s.edicion     || edicionActiva || 2026,
      capacidad:   s.capacidad   || "",
      speakerId:   (s.speakers && s.speakers[0]) ? s.speakers[0] : "",
      activo:      s.activo !== false,
    });
    setShowSessionForm(true);
  };

  const resetSessionForm = () => {
    setEditingSessionId(null);
    setSessionForm(blankSession(sedeForm, edicionActiva));
    setShowSessionForm(false);
  };

  // ────────────────────────────────────────────────────────
  // SPEAKERS
  // ────────────────────────────────────────────────────────
  const loadSpeakers = async () => {
    try {
      setLoading(true);
      const res = await API.get("/speakers");
      // GET /speakers devuelve array directo
      const list = Array.isArray(res.data) ? res.data
        : Array.isArray(res.data.speakers) ? res.data.speakers : [];
      setSpeakers(list);
    } catch (e) {
      flash("No se pudieron cargar los speakers", true);
    } finally { setLoading(false); }
  };

  const submitSpeaker = async (e) => {
    e.preventDefault();
    try {
      setLoading(true); setError(null);
      const payload = { ...speakerForm, edicion: parseInt(speakerForm.edicion) || edicionActiva || 2026 };
      if (editingSpeakerId) {
        await API.put(`/speakers/${editingSpeakerId}`, payload);
        flash("Speaker actualizado");
      } else {
        await API.post("/speakers", payload);
        flash("Speaker creado");
      }
      resetSpeakerForm();
      loadSpeakers();
    } catch (e) {
      flash(e.response?.data?.error || e.message, true);
    } finally { setLoading(false); }
  };

  const deleteSpeaker = async (id) => {
    if (!confirm("¿Eliminar este speaker?")) return;
    try {
      await API.delete(`/speakers/${id}`);
      setSpeakers(s => s.filter(x => x.id !== id));
      flash("Speaker eliminado");
    } catch (e) { flash(e.response?.data?.error || e.message, true); }
  };

  const editSpeaker = (s) => {
    setEditingSpeakerId(s.id);
    setSpeakerForm({
      nombre:       s.nombre       || "",
      bio:          s.bio          || "",
      company:      s.company      || "",
      photo_url:    s.photo_url    || "",
      cargo:        s.cargo        || "",
      email:        s.email        || "",
      telefono:     s.telefono     || "",
      linkedin_url: s.linkedin_url || "",
      twitter_url:  s.twitter_url  || "",
      website_url:  s.website_url  || "",
      sede:         s.sede         || sedeForm,
      edicion:      s.edicion      || edicionActiva || 2026,
      activo:       s.activo !== false,
    });
    setShowSpeakerForm(true);
  };

  const resetSpeakerForm = () => {
    setEditingSpeakerId(null);
    setSpeakerForm(blankSpeaker(sedeForm, edicionActiva));
    setShowSpeakerForm(false);
  };

  // ────────────────────────────────────────────────────────
  // EXPOSITORES
  // ────────────────────────────────────────────────────────
  const loadExpositores = async () => {
    try {
      setLoading(true);
      const res = await API.get("/expositores");
      const list = Array.isArray(res.data) ? res.data
        : Array.isArray(res.data.expositores) ? res.data.expositores : [];
      setExpositores(list);
    } catch (e) {
      flash("No se pudieron cargar los expositores", true);
    } finally { setLoading(false); }
  };

  const submitExpositor = async (e) => {
    e.preventDefault();
    try {
      setLoading(true); setError(null);
      // contact es JSONB en la DB
      const contact = {
        email:    expositorForm.contact_email    || "",
        telefono: expositorForm.contact_telefono || "",
        nombre:   expositorForm.contact_nombre   || "",
      };
      const payload = {
        nombre:      expositorForm.nombre,
        descripcion: expositorForm.descripcion,
        stand:       expositorForm.stand,
        logo_url:    expositorForm.logo_url,
        categoria:   expositorForm.categoria,
        website_url: expositorForm.website_url,
        contact,
        sede:        expositorForm.sede,
        edicion:     parseInt(expositorForm.edicion) || edicionActiva || 2026,
        activo:      expositorForm.activo !== false,
      };
      if (editingExpositorId) {
        await API.put(`/expositores/${editingExpositorId}`, payload);
        flash("Expositor actualizado");
      } else {
        await API.post("/expositores", payload);
        flash("Expositor creado");
      }
      resetExpositorForm();
      loadExpositores();
    } catch (e) {
      flash(e.response?.data?.error || e.message, true);
    } finally { setLoading(false); }
  };

  const deleteExpositor = async (id) => {
    if (!confirm("¿Eliminar este expositor?")) return;
    try {
      await API.delete(`/expositores/${id}`);
      setExpositores(s => s.filter(x => x.id !== id));
      flash("Expositor eliminado");
    } catch (e) { flash(e.response?.data?.error || e.message, true); }
  };

  const editExpositor = (ex) => {
    setEditingExpositorId(ex.id);
    const c = ex.contact || {};
    setExpositorForm({
      nombre:           ex.nombre      || "",
      descripcion:      ex.descripcion || "",
      stand:            ex.stand       || "",
      logo_url:         ex.logo_url    || "",
      categoria:        ex.categoria   || "",
      website_url:      ex.website_url || "",
      contact_email:    c.email        || "",
      contact_telefono: c.telefono     || "",
      contact_nombre:   c.nombre       || "",
      sede:             ex.sede        || sedeForm,
      edicion:          ex.edicion     || edicionActiva || 2026,
      activo:           ex.activo !== false,
    });
    setShowExpositorForm(true);
  };

  const resetExpositorForm = () => {
    setEditingExpositorId(null);
    setExpositorForm(blankExpositor(sedeForm, edicionActiva));
    setShowExpositorForm(false);
  };

  // ────────────────────────────────────────────────────────
  // NOTIFICACIONES
  // ────────────────────────────────────────────────────────
  const loadUsers = async () => {
    try {
      const res = await API.get("/users");
      // GET /users devuelve array directo según el backend
      setUsers(Array.isArray(res.data) ? res.data
        : Array.isArray(res.data.users) ? res.data.users : []);
    } catch (e) { console.error("Error cargando usuarios:", e); }
  };

  const submitNoti = async (e) => {
    e.preventDefault();
    if (!notiForm.titulo?.trim() || !notiForm.mensaje?.trim()) {
      setNotiError("Título y mensaje son requeridos"); return;
    }
    try {
      setNotiLoading(true); setNotiError(null);
      await API.post("/notificaciones", {
        titulo:       notiForm.titulo.trim(),
        mensaje:      notiForm.mensaje.trim(),
        tipo:         notiForm.tipo || "info",
        tipo_usuario: notiForm.tipo_usuario?.length > 0 ? notiForm.tipo_usuario : ["todos"],
        sede:         notiForm.sede || "todos",
        activa:       true,
      });
      flash("Notificación enviada correctamente");
      setShowNotiForm(false);
      setNotiForm(blankNoti());
    } catch (e) {
      setNotiError(e.response?.data?.error || e.message);
    } finally { setNotiLoading(false); }
  };

  const toggleTipoUsuario = (tipo) => {
    setNotiForm(prev => ({
      ...prev,
      tipo_usuario: prev.tipo_usuario.includes(tipo)
        ? prev.tipo_usuario.filter(t => t !== tipo)
        : [...prev.tipo_usuario.filter(t => t !== "todos"), tipo],
    }));
  };

  // ────────────────────────────────────────────────────────
  // GUARD
  // ────────────────────────────────────────────────────────
  if (!userProfile) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-blue-600" size={32} /></div>;
  }

  const isAdmin = userProfile.rol === "super_admin";
  const isStaff = userProfile.rol === "staff";

  if (!isAdmin && !isStaff) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 p-6 rounded-2xl flex items-center gap-3">
        <AlertCircle className="text-red-500 shrink-0" size={24} />
        <div>
          <p className="font-bold text-red-800 dark:text-red-300">Acceso restringido</p>
          <p className="text-sm text-red-600 dark:text-red-400 mt-1">Solo Super Admin y Staff pueden acceder a este panel.</p>
        </div>
      </div>
    );
  }

  // Tabs disponibles según rol
  const TABS = [
    { id: "sesiones",       label: "📅 Sesiones",        icon: Calendar  },
    { id: "eventos",        label: "⏱ Minuto a Minuto",  icon: Clock     },
    { id: "speakers",       label: "🎤 Speakers",         icon: Mic       },
    { id: "expositores",    label: "🏢 Expositores",      icon: Building2 },
    ...(isAdmin ? [{ id: "mapa_stands",    label: "🗺 Mapa Stands",    icon: Map  }] : []),
    ...(isAdmin ? [{ id: "notificaciones", label: "🔔 Notificaciones", icon: Bell }] : []),
  ];

  const TIPOS_EVENTO = [
    { v: 'registro',     l: '📋 Registro / Check-in' },
    { v: 'recepcion',    l: '🤝 Recepción' },
    { v: 'expo_abierta', l: '🏢 Expo Abierta' },
    { v: 'keynote',      l: '🎙 Keynote' },
    { v: 'coffee_break', l: '☕ Coffee Break' },
    { v: 'almuerzo',     l: '🍽 Almuerzo' },
    { v: 'networking',   l: '🤝 Networking' },
    { v: 'clausura',     l: '🏁 Clausura' },
    { v: 'otro',         l: '📌 Otro' },
  ];

  // ────────────────────────────────────────────────────────
  // RENDER
  // ────────────────────────────────────────────────────────
  return (
    <div className="max-w-7xl mx-auto space-y-5">

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-gray-900 dark:text-white">
            Panel de Administración
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            {isAdmin ? "Super Admin" : "Staff"} ·{" "}
            Sede: <span className="font-semibold capitalize">{sedeActiva || "todas"}</span> ·{" "}
            Edición: <span className="font-semibold">{edicionActiva || 2026}</span>
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => navigate("/usuarios")} className={btnGhost}>
            <Users size={16} /> Usuarios <ExternalLink size={12} />
          </button>
          {isAdmin && (
            <button onClick={() => navigate("/admin/import")} className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl hover:bg-emerald-700 font-semibold text-sm transition">
              <FileUp size={16} /> Importar Excel
            </button>
          )}
        </div>
      </div>

      {/* Alertas */}
      {success && (
        <div className="flex items-center gap-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 text-green-800 dark:text-green-300 px-4 py-3 rounded-xl text-sm">
          <CheckCircle size={16} /> {success}
        </div>
      )}
      {error && (
        <div className="flex items-center gap-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 text-red-800 dark:text-red-300 px-4 py-3 rounded-xl text-sm">
          <AlertCircle size={16} /> {error}
          <button onClick={() => setError(null)} className="ml-auto"><X size={14} /></button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-xl text-sm font-semibold transition border-2
              ${activeTab === tab.id
                ? "bg-blue-600 text-white border-blue-600"
                : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-blue-400"}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ═══════════════════════════════════════════════════
          TAB: SESIONES
      ═══════════════════════════════════════════════════ */}
      {activeTab === "sesiones" && (
        <div className="space-y-4">
          {/* Barra de control de sesiones */}
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="text-xl font-bold dark:text-white flex-1">Sesiones ({sessionsFiltradas.length}{filtroSede ? ` de ${sessions.length}` : ""})</h2>
            {/* Filtro por sede */}
            <select
              value={filtroSede}
              onChange={e => setFiltroSede(e.target.value)}
              className="text-sm border border-gray-300 dark:border-gray-600 rounded-xl px-3 py-1.5 bg-white dark:bg-gray-700 dark:text-white"
            >
              <option value="">Todas las sedes</option>
              {[...new Set(sessions.map(s => {
                  // Normalizar abreviaturas a nombres completos
                  const norm = { cl:'chile', mx:'mexico', co:'colombia', pe:'peru', ar:'argentina' };
                  return norm[(s.sede||'').toLowerCase()] || (s.sede||'').toLowerCase();
                }).filter(Boolean))].sort().map(s => (
                <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase()+s.slice(1)}</option>
              ))}
            </select>
            {/* Botón sync WP */}
            <button onClick={() => handleSyncWp(false)} disabled={syncing}
              title="Sincronizar sesiones desde WordPress"
              className="flex items-center gap-2 border border-blue-300 dark:border-blue-600 text-blue-600 dark:text-blue-400 px-3 py-1.5 rounded-xl text-sm hover:bg-blue-50 dark:hover:bg-blue-900/20 disabled:opacity-50 transition font-semibold">
              <RefreshCw size={15} className={syncing ? "animate-spin" : ""} />
              {syncing ? "Sincronizando..." : "Sincronizar WP"}
            </button>
            {/* Config WP */}
            {isAdmin && (
              <button onClick={() => setShowWpPanel(p => !p)}
                className="flex items-center gap-1.5 border border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-400 px-3 py-1.5 rounded-xl text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition">
                <Wifi size={15} /> Config WP
              </button>
            )}
            {isAdmin && (
              <button onClick={() => { resetSessionForm(); setShowSessionForm(true); }} className={btnPrimary}>
                <Plus size={16} /> Nueva Sesión
              </button>
            )}
          </div>

          {/* Panel configuración WordPress */}
          {showWpPanel && (
            <div className="bg-blue-50 dark:bg-blue-900/10 border border-blue-200 dark:border-blue-700 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-blue-800 dark:text-blue-300 flex items-center gap-2"><Wifi size={16} /> Conexión con WordPress</h3>
                {wpConfig?.ultima_sync_wp && (
                  <span className="text-xs text-gray-500">Última sync: {new Date(wpConfig.ultima_sync_wp).toLocaleString("es")}</span>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-3">
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase mb-1">URL de la API WordPress</label>
                  <input className={inputCls} value={wpForm.wp_api_url}
                    onChange={e => setWpForm(p=>({...p,wp_api_url:e.target.value}))}
                    placeholder="https://mi-sitio.com/wp-json/wp/v2" />
                  <p className="text-xs text-gray-400 mt-0.5">Cambia esto si migraste tu sitio WordPress a otro dominio.</p>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase mb-1">Usuario WordPress</label>
                  <input className={inputCls} value={wpForm.wp_username}
                    onChange={e => setWpForm(p=>({...p,wp_username:e.target.value}))}
                    placeholder="admin" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase mb-1">Contraseña de aplicación</label>
                  <input type="password" className={inputCls} value={wpForm.wp_app_password}
                    onChange={e => setWpForm(p=>({...p,wp_app_password:e.target.value}))}
                    placeholder="xxxx xxxx xxxx xxxx (Application Password de WP)" />
                </div>
              </div>
              {wpTestResult && (
                <div className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm ${
                  wpTestResult.ok ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                }`}>
                  {wpTestResult.ok ? <Wifi size={14}/> : <WifiOff size={14}/>}
                  {wpTestResult.mensaje}
                </div>
              )}
              <div className="flex gap-2">
                <button onClick={handleTestWp} disabled={testingWp}
                  className="flex items-center gap-2 border border-blue-400 text-blue-600 px-4 py-2 rounded-xl text-sm hover:bg-blue-50 disabled:opacity-50 font-semibold transition">
                  <Wifi size={15}/> {testingWp ? "Probando..." : "Probar conexión"}
                </button>
                <button onClick={handleSaveWpConfig}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl text-sm hover:bg-blue-700 font-semibold transition">
                  <Save size={15}/> Guardar y aplicar
                </button>
                <button onClick={() => handleSyncWp(true)} disabled={syncing}
                  className="flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-xl text-sm hover:bg-orange-600 disabled:opacity-50 font-semibold transition">
                  <RefreshCw size={15} className={syncing?"animate-spin":""}/> Re-sync completo
                </button>
              </div>
            </div>
          )}

          {/* Sesiones sin título — panel de recuperación */}
          {sinTitulo.length > 0 && (
            <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-600 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-amber-700 dark:text-amber-300">
                  ⚠️ {sinTitulo.length} sesión(es) sin título detectada(s)
                </p>
                <button onClick={() => handleSyncWp(true)} disabled={syncing}
                  className="text-xs bg-amber-500 text-white px-3 py-1.5 rounded-lg hover:bg-amber-600 font-semibold transition">
                  Recuperar desde WP
                </button>
              </div>
              <p className="text-xs text-amber-600 dark:text-amber-400">
                Estas sesiones fueron editadas y perdieron su título. Usa "Recuperar desde WP" para restaurar los datos originales desde WordPress.
              </p>
            </div>
          )}


          {showSessionForm && (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border-l-4 border-blue-500 border border-gray-200 dark:border-gray-700 p-6 space-y-4">
              <h3 className="font-bold text-lg dark:text-white">{editingSessionId ? "✏️ Editar Sesión" : "Nueva Sesión"}</h3>
              <form onSubmit={submitSession} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Título *">
                    <input className={inputCls} placeholder="Título de la sesión" value={sessionForm.title}
                      onChange={e => setSessionForm(p => ({...p, title: e.target.value}))} required />
                  </Field>
                  <Field label="Sala / Room">
                    <input className={inputCls} placeholder="Sala o Auditorio" value={sessionForm.sala}
                      onChange={e => setSessionForm(p => ({...p, sala: e.target.value, room: e.target.value}))} />
                  </Field>
                  <Field label="Inicio">
                    <input type="datetime-local" className={inputCls} value={sessionForm.start_at}
                      onChange={e => setSessionForm(p => ({...p, start_at: e.target.value}))} />
                  </Field>
                  <Field label="Fin">
                    <input type="datetime-local" className={inputCls} value={sessionForm.end_at}
                      onChange={e => setSessionForm(p => ({...p, end_at: e.target.value}))} />
                  </Field>
                  <Field label="Descripción">
                    <textarea className={inputCls} rows={2} placeholder="Descripción" value={sessionForm.description}
                      onChange={e => setSessionForm(p => ({...p, description: e.target.value}))} />
                  </Field>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Día (1-4)">
                      <select className={inputCls} value={sessionForm.dia}
                        onChange={e => setSessionForm(p => ({...p, dia: parseInt(e.target.value)}))}>
                        {[1,2,3,4].map(d => <option key={d} value={d}>Día {d}</option>)}
                      </select>
                    </Field>
                    <Field label="Capacidad">
                      <input type="number" className={inputCls} placeholder="Máx. asistentes" value={sessionForm.capacidad}
                        onChange={e => setSessionForm(p => ({...p, capacidad: e.target.value}))} />
                    </Field>
                  </div>
                  <Field label="Tipo">
                    <select className={inputCls} value={sessionForm.tipo}
                      onChange={e => setSessionForm(p => ({...p, tipo: e.target.value}))}>
                      {["sesion","curso","keynote","taller","panel","networking"].map(t =>
                        <option key={t} value={t} className="capitalize">{t.charAt(0).toUpperCase()+t.slice(1)}</option>
                      )}
                    </select>
                  </Field>
                  <Field label="Categoría">
                    <select className={inputCls} value={sessionForm.categoria}
                      onChange={e => setSessionForm(p => ({...p, categoria: e.target.value}))}>
                      {["brujula","toolbox","spark","orion","tracker","curso","general"].map(c =>
                        <option key={c} value={c} className="capitalize">{c.charAt(0).toUpperCase()+c.slice(1)}</option>
                      )}
                    </select>
                  </Field>
                  <Field label="Sede">
                    <select className={inputCls} value={sessionForm.sede}
                      onChange={e => setSessionForm(p => ({...p, sede: e.target.value}))}>
                      {SEDES.map(s => <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
                    </select>
                  </Field>
                  <Field label="Edición (año)">
                    <input type="number" className={inputCls} value={sessionForm.edicion}
                      onChange={e => setSessionForm(p => ({...p, edicion: e.target.value}))} />
                  </Field>
                  <Field label="Speaker / Instructor">
                    <select className={inputCls} value={sessionForm.speakerId}
                      onChange={e => setSessionForm(p => ({...p, speakerId: e.target.value}))}>
                      <option value="">Sin speaker asignado</option>
                      {speakers.map(sp => (
                        <option key={sp.id} value={sp.id}>
                          {sp.nombre}{sp.cargo ? ` — ${sp.cargo}` : ""}
                        </option>
                      ))}
                    </select>
                  </Field>
                </div>
                <div className="flex gap-3 pt-2">
                  <button type="submit" disabled={loading} className={btnPrimary}>
                    {loading ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                    {editingSessionId ? "Guardar Cambios" : "Crear Sesión"}
                  </button>
                  <button type="button" onClick={resetSessionForm} className={btnGhost}><X size={16} />Cancelar</button>
                </div>
              </form>
            </div>
          )}

          {loading && !sessions.length ? (
            <div className="flex justify-center py-12"><Loader2 className="animate-spin text-blue-600" size={28} /></div>
          ) : sessions.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Calendar size={40} className="mx-auto mb-2 opacity-30" />
              <p>No hay sesiones registradas</p>
            </div>
          ) : (
            <div className="space-y-2">
              {sessionsFiltradas.map(s => (
                <div key={s.id} className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-start justify-between gap-4 hover:shadow-sm transition">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap gap-2 items-center">
                      <span className="font-bold text-gray-900 dark:text-white truncate">{s.titulo || s.title || "(sin título)"}</span>
                      {/* Indicador de origen */}
                      {s.source === "wordpress" && !s.isOverride && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-900/30 text-sky-700 dark:text-sky-300 font-semibold shrink-0">WP</span>
                      )}
                      {s.isOverride && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 font-semibold shrink-0">WP editada</span>
                      )}
                      {s.source === "local" && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 font-semibold shrink-0">Local</span>
                      )}

                      <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 capitalize">{s.tipo}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 capitalize">{s.categoria}</span>
                      {!s.activo && <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">Inactiva</span>}
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 truncate">{s.descripcion || s.description}</p>
                    <div className="flex flex-wrap gap-3 text-xs text-gray-400 mt-1">
                      {s.sala && <span>📍 {s.sala}</span>}
                      {s.dia && <span>Día {s.dia}</span>}
                      {s.start_at && <span>🕐 {new Date(s.start_at).toLocaleTimeString("es", {hour:"2-digit",minute:"2-digit"})}</span>}
                      <span className="capitalize">{s.sede}</span>
                      {s.speakers && s.speakers.length > 0 && speakers.find(sp => sp.id === s.speakers[0]) && (
                        <span className="text-blue-600 dark:text-blue-400">
                          👤 {speakers.find(sp => sp.id === s.speakers[0])?.nombre}
                        </span>
                      )}
                    </div>
                  </div>
                  {isAdmin && (
                    <div className="flex gap-1 shrink-0">
                      <button onClick={() => editSession(s)} className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition"><Edit2 size={16} /></button>
                      <button onClick={() => deleteSession(s.id)} className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"><Trash2 size={16} /></button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════
          TAB: SPEAKERS
      ═══════════════════════════════════════════════════ */}
      {activeTab === "speakers" && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="text-xl font-bold dark:text-white flex-1">Speakers ({speakers.length})</h2>
            <button onClick={async () => {
              if (!confirm('¿Sincronizar speakers desde WordPress? Esto importará todos los speakers del sitio a la DB local.')) return;
              setLoading(true);
              try {
                const r = await API.post('/speakers/sync-from-wp');
                flash(`✅ ${r.data.message}`);
                loadSpeakers();
              } catch(e) { flash(e.response?.data?.error || 'Error al sincronizar', true); }
              finally { setLoading(false); }
            }}
              className="flex items-center gap-2 border border-blue-300 dark:border-blue-600 text-blue-600 dark:text-blue-400 px-3 py-1.5 rounded-xl text-sm hover:bg-blue-50 dark:hover:bg-blue-900/20 font-semibold transition">
              <RefreshCw size={14} /> Sync desde WP
            </button>
            <button onClick={() => { resetSpeakerForm(); setShowSpeakerForm(true); }} className={btnPrimary}>
              <Plus size={16} /> Nuevo Speaker
            </button>
          </div>

          {showSpeakerForm && (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border-l-4 border-green-500 border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="font-bold text-lg dark:text-white mb-4">{editingSpeakerId ? "✏️ Editar Speaker" : "Nuevo Speaker"}</h3>
              <form onSubmit={submitSpeaker} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Nombre *">
                    <input className={inputCls} placeholder="Nombre completo" value={speakerForm.nombre}
                      onChange={e => setSpeakerForm(p => ({...p, nombre: e.target.value}))} required />
                  </Field>
                  <Field label="Cargo">
                    <input className={inputCls} placeholder="Director / Gerente..." value={speakerForm.cargo}
                      onChange={e => setSpeakerForm(p => ({...p, cargo: e.target.value}))} />
                  </Field>
                  <Field label="Empresa / Company">
                    <input className={inputCls} placeholder="Empresa" value={speakerForm.company}
                      onChange={e => setSpeakerForm(p => ({...p, company: e.target.value}))} />
                  </Field>
                  <Field label="Email">
                    <input type="email" className={inputCls} placeholder="email@empresa.com" value={speakerForm.email}
                      onChange={e => setSpeakerForm(p => ({...p, email: e.target.value}))} />
                  </Field>
                  <Field label="Teléfono">
                    <input type="tel" className={inputCls} placeholder="+52 55 0000 0000" value={speakerForm.telefono}
                      onChange={e => setSpeakerForm(p => ({...p, telefono: e.target.value}))} />
                  </Field>
                  <Field label="URL Foto (photo_url)">
                    <input type="url" className={inputCls} placeholder="https://..." value={speakerForm.photo_url}
                      onChange={e => setSpeakerForm(p => ({...p, photo_url: e.target.value}))} />
                  </Field>
                  <Field label="LinkedIn">
                    <input type="url" className={inputCls} placeholder="https://linkedin.com/in/..." value={speakerForm.linkedin_url}
                      onChange={e => setSpeakerForm(p => ({...p, linkedin_url: e.target.value}))} />
                  </Field>
                  <Field label="Twitter / X">
                    <input type="url" className={inputCls} placeholder="https://twitter.com/..." value={speakerForm.twitter_url}
                      onChange={e => setSpeakerForm(p => ({...p, twitter_url: e.target.value}))} />
                  </Field>
                  <Field label="Website">
                    <input type="url" className={inputCls} placeholder="https://..." value={speakerForm.website_url}
                      onChange={e => setSpeakerForm(p => ({...p, website_url: e.target.value}))} />
                  </Field>
                  <Field label="Sede">
                    <select className={inputCls} value={speakerForm.sede}
                      onChange={e => setSpeakerForm(p => ({...p, sede: e.target.value}))}>
                      {SEDES.map(s => <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
                    </select>
                  </Field>
                  <Field label="Biografía">
                    <textarea className={inputCls} rows={3} placeholder="Breve descripción del speaker..." value={speakerForm.bio}
                      onChange={e => setSpeakerForm(p => ({...p, bio: e.target.value}))} />
                  </Field>
                  <Field label="Edición">
                    <input type="number" className={inputCls} value={speakerForm.edicion}
                      onChange={e => setSpeakerForm(p => ({...p, edicion: e.target.value}))} />
                  </Field>
                </div>
                {speakerForm.photo_url && (
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <img src={speakerForm.photo_url} alt="" className="w-14 h-14 rounded-full object-cover border"
                      onError={e => e.target.style.display="none"} />
                    <span>Vista previa de foto</span>
                  </div>
                )}
                <div className="flex gap-3 pt-2">
                  <button type="submit" disabled={loading} className={btnPrimary}>
                    {loading ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                    {editingSpeakerId ? "Guardar Cambios" : "Crear Speaker"}
                  </button>
                  <button type="button" onClick={resetSpeakerForm} className={btnGhost}><X size={16} />Cancelar</button>
                </div>
              </form>
            </div>
          )}

          {loading && !speakers.length ? (
            <div className="flex justify-center py-12"><Loader2 className="animate-spin text-blue-600" size={28} /></div>
          ) : speakers.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Mic size={40} className="mx-auto mb-2 opacity-30" />
              <p>No hay speakers registrados</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {speakers.map(s => (
                <div key={s.id} className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition">
                  <div className="flex items-center gap-3 mb-3">
                    <img src={s.photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(s.nombre)}&background=1a3a5c&color=fff`}
                      alt={s.nombre} className="w-12 h-12 rounded-full object-cover border shrink-0"
                      onError={e => { e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(s.nombre)}&background=1a3a5c&color=fff`; }} />
                    <div className="min-w-0">
                      <p className="font-bold text-gray-900 dark:text-white text-sm truncate">{s.nombre}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{s.cargo}</p>
                      <p className="text-xs text-gray-400 truncate">{s.company}</p>
                    </div>
                  </div>
                  {s.bio && <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 mb-3">{s.bio}</p>}
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400 capitalize">{s.sede}</span>
                    <div className="flex gap-1">
                      <button onClick={() => editSpeaker(s)} className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition"><Edit2 size={14} /></button>
                      <button onClick={() => deleteSpeaker(s.id)} className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"><Trash2 size={14} /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════
          TAB: EXPOSITORES
      ═══════════════════════════════════════════════════ */}
      {activeTab === "expositores" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold dark:text-white">Expositores ({expositores.length})</h2>
            <button onClick={() => { resetExpositorForm(); setShowExpositorForm(true); }} className={btnPrimary}>
              <Plus size={16} /> Nuevo Expositor
            </button>
          </div>

          {showExpositorForm && (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border-l-4 border-purple-500 border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="font-bold text-lg dark:text-white mb-4">{editingExpositorId ? "✏️ Editar Expositor" : "Nuevo Expositor"}</h3>
              <form onSubmit={submitExpositor} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Nombre empresa *">
                    <input className={inputCls} placeholder="Nombre de la empresa" value={expositorForm.nombre}
                      onChange={e => setExpositorForm(p => ({...p, nombre: e.target.value}))} required />
                  </Field>
                  <Field label="Tipo de Stand / Categoría">
                    <select className={inputCls} value={expositorForm.categoria}
                      onChange={e => setExpositorForm(p => ({...p, categoria: e.target.value}))}>
                      <option value="">— Seleccionar tipo —</option>
                      {(CATEGORIAS_POR_SEDE[(expositorForm.sede || sedeForm || "colombia").toLowerCase()]
                        || CATEGORIAS_POR_SEDE.colombia
                      ).map(cat => (
                        <option key={cat.key} value={cat.key}>
                          {cat.label} — {cat.ancho_m}×{cat.alto_m}m ({cat.celdas_ancho}×{cat.celdas_alto} celdas)
                        </option>
                      ))}
                    </select>
                    {expositorForm.categoria && (() => {
                      const cats = CATEGORIAS_POR_SEDE[(expositorForm.sede || sedeForm || "colombia").toLowerCase()]
                        || CATEGORIAS_POR_SEDE.colombia;
                      const cat = cats.find(c => c.key === expositorForm.categoria);
                      return cat ? (
                        <p className="text-xs mt-1 font-semibold" style={{ color: cat.color }}>
                          ● {cat.label} · {cat.ancho_m}×{cat.alto_m}m · ocupa {cat.celdas_ancho}×{cat.celdas_alto} celdas en el mapa
                        </p>
                      ) : null;
                    })()}
                  </Field>
                  <Field label="Stand #">
                    <input className={inputCls} placeholder="A-01" value={expositorForm.stand}
                      onChange={e => setExpositorForm(p => ({...p, stand: e.target.value}))} />
                  </Field>
                  <Field label="Website">
                    <input type="url" className={inputCls} placeholder="https://empresa.com" value={expositorForm.website_url}
                      onChange={e => setExpositorForm(p => ({...p, website_url: e.target.value}))} />
                  </Field>
                  <Field label="Logo URL">
                    <input type="url" className={inputCls} placeholder="https://..." value={expositorForm.logo_url}
                      onChange={e => setExpositorForm(p => ({...p, logo_url: e.target.value}))} />
                  </Field>
                  <Field label="Sede">
                    <select className={inputCls} value={expositorForm.sede}
                      onChange={e => setExpositorForm(p => ({...p, sede: e.target.value}))}>
                      {SEDES.map(s => <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
                    </select>
                  </Field>
                  <Field label="Descripción">
                    <textarea className={inputCls} rows={2} placeholder="Descripción breve..." value={expositorForm.descripcion}
                      onChange={e => setExpositorForm(p => ({...p, descripcion: e.target.value}))} />
                  </Field>
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase">Contacto</p>
                    <input className={inputCls} placeholder="Nombre del contacto" value={expositorForm.contact_nombre}
                      onChange={e => setExpositorForm(p => ({...p, contact_nombre: e.target.value}))} />
                    <input type="email" className={inputCls} placeholder="email@empresa.com" value={expositorForm.contact_email}
                      onChange={e => setExpositorForm(p => ({...p, contact_email: e.target.value}))} />
                    <input type="tel" className={inputCls} placeholder="Teléfono de contacto" value={expositorForm.contact_telefono}
                      onChange={e => setExpositorForm(p => ({...p, contact_telefono: e.target.value}))} />
                  </div>
                </div>
                {expositorForm.logo_url && (
                  <img src={expositorForm.logo_url} alt="" className="h-14 object-contain border rounded-lg p-1"
                    onError={e => e.target.style.display="none"} />
                )}
                <div className="flex gap-3 pt-2">
                  <button type="submit" disabled={loading} className={btnPrimary}>
                    {loading ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                    {editingExpositorId ? "Guardar Cambios" : "Crear Expositor"}
                  </button>
                  <button type="button" onClick={resetExpositorForm} className={btnGhost}><X size={16} />Cancelar</button>
                </div>
              </form>
            </div>
          )}

          {loading && !expositores.length ? (
            <div className="flex justify-center py-12"><Loader2 className="animate-spin text-blue-600" size={28} /></div>
          ) : expositores.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Building2 size={40} className="mx-auto mb-2 opacity-30" />
              <p>No hay expositores registrados</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {expositores.map(ex => (
                <div key={ex.id} className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition">
                  {ex.logo_url && (
                    <img src={ex.logo_url} alt={ex.nombre} className="w-full h-20 object-contain rounded-xl mb-3 bg-gray-50 dark:bg-gray-700 p-2"
                      onError={e => e.target.style.display="none"} />
                  )}
                  <h3 className="font-bold text-gray-900 dark:text-white text-sm">{ex.nombre}</h3>
                  {ex.categoria && <p className="text-xs text-gray-500 dark:text-gray-400">{ex.categoria}</p>}
                  {ex.stand && <p className="text-xs text-gray-400">Stand: {ex.stand}</p>}
                  {ex.descripcion && <p className="text-xs text-gray-400 mt-1 line-clamp-2">{ex.descripcion}</p>}
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-gray-400 capitalize">{ex.sede}</span>
                    <div className="flex gap-1">
                      <button onClick={() => editExpositor(ex)} className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition"><Edit2 size={14} /></button>
                      <button onClick={() => deleteExpositor(ex.id)} className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"><Trash2 size={14} /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ═══════ TAB: MAPA DE STANDS ═══════ */}
      {activeTab === "mapa_stands" && (
        <div className="space-y-6">
          <h2 className="text-xl font-bold dark:text-white flex items-center gap-2">
            <Map size={22} className="text-blue-600" />
            Mapa de Stands
          </h2>
          <MapaStandsAdmin
            expositores={expositores}
            sedeActiva={sedeForm}
            flash={flash}
            loadExpositores={loadExpositores}
          />
        </div>
      )}


      {/* ═══════════════════════════════════════════════════
          TAB: MINUTO A MINUTO (EVENTOS LOGÍSTICA)
      ═══════════════════════════════════════════════════ */}
      {activeTab === "eventos" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold dark:text-white">Minuto a Minuto</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">Espacios logísticos del evento: registro, recepción, breaks, etc.</p>
            </div>
            {isAdmin && (
              <button onClick={() => { setEditingEventoId(null); setShowEventoForm(true); }} className={btnPrimary}>
                <Plus size={16} /> Agregar Espacio
              </button>
            )}
          </div>

          {/* Formulario */}
          {showEventoForm && (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border-l-4 border-purple-500 border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="font-bold text-lg dark:text-white mb-4">{editingEventoId ? "✏️ Editar Espacio" : "Nuevo Espacio"}</h3>
              <form onSubmit={submitEvento} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Nombre del espacio *">
                  <input className={inputCls} required value={eventoForm.titulo}
                    placeholder="Ej: Registro de asistentes, Coffee Break"
                    onChange={e => setEventoForm(p => ({...p, titulo: e.target.value}))} />
                </Field>
                <Field label="Tipo">
                  <select className={inputCls} value={eventoForm.tipo}
                    onChange={e => setEventoForm(p => ({...p, tipo: e.target.value}))}>
                    {TIPOS_EVENTO.map(t => <option key={t.v} value={t.v}>{t.l}</option>)}
                  </select>
                </Field>
                <Field label="Día">
                  <select className={inputCls} value={eventoForm.dia}
                    onChange={e => setEventoForm(p => ({...p, dia: e.target.value}))}>
                    {[1,2,3,4].map(d => <option key={d} value={d}>Día {d}</option>)}
                  </select>
                </Field>
                <Field label="Sala / Ubicación">
                  <input className={inputCls} value={eventoForm.sala}
                    placeholder="Ej: Lobby, Hall Principal"
                    onChange={e => setEventoForm(p => ({...p, sala: e.target.value}))} />
                </Field>
                <Field label="Hora inicio">
                  <input type="datetime-local" className={inputCls} value={eventoForm.horaInicio}
                    onChange={e => setEventoForm(p => ({...p, horaInicio: e.target.value}))} />
                </Field>
                <Field label="Hora fin">
                  <input type="datetime-local" className={inputCls} value={eventoForm.horaFin}
                    onChange={e => setEventoForm(p => ({...p, horaFin: e.target.value}))} />
                </Field>
                <div className="md:col-span-2 flex gap-3 pt-2">
                  <button type="submit" disabled={loading} className={btnPrimary}>
                    {loading ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                    {editingEventoId ? "Guardar Cambios" : "Crear Espacio"}
                  </button>
                  <button type="button" onClick={() => setShowEventoForm(false)} className={btnGhost}>
                    <X size={16} /> Cancelar
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Lista por día */}
          {[1,2,3,4].map(dia => {
            const del_dia = eventos.filter(e => parseInt(e.dia) === dia);
            if (del_dia.length === 0) return null;
            return (
              <div key={dia}>
                <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">
                  <Clock size={13} className="inline mr-1" /> Día {dia}
                </h3>
                <div className="space-y-2">
                  {del_dia.sort((a,b) => (a.horaInicio||'') < (b.horaInicio||'') ? -1 : 1).map(ev => {
                    const tipoLabel = TIPOS_EVENTO.find(t => t.v === ev.tipo)?.l || ev.tipo;
                    return (
                      <div key={ev.id} className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <span className="text-2xl">{tipoLabel.split(' ')[0]}</span>
                          <div className="min-w-0">
                            <p className="font-semibold text-gray-900 dark:text-white truncate">{ev.titulo || ev.title}</p>
                            <div className="flex flex-wrap gap-2 text-xs text-gray-500 mt-0.5">
                              {ev.horaInicio && <span>🕐 {new Date(ev.horaInicio).toLocaleTimeString('es',{hour:'2-digit',minute:'2-digit'})}{ev.horaFin ? ` – ${new Date(ev.horaFin).toLocaleTimeString('es',{hour:'2-digit',minute:'2-digit'})}` : ''}</span>}
                              {ev.sala && <span>📍 {ev.sala}</span>}
                              <span className="capitalize text-purple-600 dark:text-purple-400">{tipoLabel.slice(3)}</span>
                            </div>
                          </div>
                        </div>
                        {isAdmin && (
                          <div className="flex gap-1 shrink-0">
                            <button onClick={() => { setEditingEventoId(ev.id); setEventoForm({ titulo: ev.titulo||ev.title||'', dia: ev.dia||1, horaInicio: ev.horaInicio?String(ev.horaInicio).slice(0,16):'', horaFin: ev.horaFin?String(ev.horaFin).slice(0,16):'', tipo: ev.tipo||'registro', sala: ev.sala||'' }); setShowEventoForm(true); }}
                              className="p-1.5 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition">
                              <Edit2 size={14} />
                            </button>
                            <button onClick={async () => { if(confirm('¿Eliminar este espacio?')) { await API.delete(`/agenda/sessions/${ev.id}`); loadEventos(); } }}
                              className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {eventos.length === 0 && !showEventoForm && (
            <div className="text-center py-12 text-gray-400">
              <Clock size={40} className="mx-auto mb-2 opacity-30" />
              <p>No hay espacios logísticos registrados</p>
              <p className="text-sm mt-1">Agrega el registro, recepción, breaks, etc.</p>
            </div>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════
          TAB: NOTIFICACIONES (solo super_admin)
      ═══════════════════════════════════════════════════ */}
      {activeTab === "notificaciones" && isAdmin && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold dark:text-white">Notificaciones</h2>
            <button onClick={() => setShowNotiForm(!showNotiForm)} className={btnPrimary}>
              <Plus size={16} /> Nueva Notificación
            </button>
          </div>

          {showNotiForm && (
            <div className="bg-white dark:bg-gray-800 rounded-2xl border-l-4 border-yellow-500 border border-gray-200 dark:border-gray-700 p-6 space-y-4">
              <h3 className="font-bold text-lg dark:text-white">Nueva Notificación</h3>
              {notiError && (
                <div className="flex items-center gap-2 text-red-600 text-sm bg-red-50 dark:bg-red-900/30 p-3 rounded-xl">
                  <AlertCircle size={14} /> {notiError}
                </div>
              )}
              <form onSubmit={submitNoti} className="space-y-4">
                <Field label="Título *">
                  <input className={inputCls} placeholder="Título de la notificación" value={notiForm.titulo}
                    onChange={e => setNotiForm(p => ({...p, titulo: e.target.value}))} required />
                </Field>
                <Field label="Mensaje *">
                  <textarea className={inputCls} rows={3} placeholder="Contenido del mensaje..." value={notiForm.mensaje}
                    onChange={e => setNotiForm(p => ({...p, mensaje: e.target.value}))} required />
                </Field>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field label="Tipo">
                    <select className={inputCls} value={notiForm.tipo}
                      onChange={e => setNotiForm(p => ({...p, tipo: e.target.value}))}>
                      <option value="info">ℹ️ Información</option>
                      <option value="success">✅ Éxito</option>
                      <option value="warning">⚠️ Advertencia</option>
                      <option value="error">❌ Error/Urgente</option>
                    </select>
                  </Field>
                  <Field label="Sede destino">
                    <select className={inputCls} value={notiForm.sede}
                      onChange={e => setNotiForm(p => ({...p, sede: e.target.value}))}>
                      <option value="todos">Todas las sedes</option>
                      {SEDES.map(s => <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
                    </select>
                  </Field>
                </div>

                {/* Segmentación por tipo de pase */}
                <Field label="Enviar a">
                  <div className="flex flex-wrap gap-2 mt-1">
                    {TIPOS_PASE.map(tp => (
                      <button key={tp.id} type="button"
                        onClick={() => {
                          if (tp.id === "todos") {
                            setNotiForm(p => ({...p, tipo_usuario: ["todos"]}));
                          } else {
                            toggleTipoUsuario(tp.id);
                          }
                        }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold border-2 transition
                          ${(notiForm.tipo_usuario.includes(tp.id) || (tp.id === "todos" && notiForm.tipo_usuario.includes("todos")))
                            ? "border-blue-600 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300"
                            : "border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:border-gray-400"}`}
                      >
                        {tp.label}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-gray-400 mt-1">
                    Destinatarios: <strong>{notiForm.tipo_usuario.join(", ")}</strong>
                  </p>
                </Field>

                <div className="flex gap-3 pt-2">
                  <button type="submit" disabled={notiLoading} className={btnPrimary}>
                    {notiLoading ? <Loader2 size={16} className="animate-spin" /> : <Bell size={16} />}
                    {notiLoading ? "Enviando..." : "Enviar Notificación"}
                  </button>
                  <button type="button" onClick={() => { setShowNotiForm(false); setNotiForm(blankNoti()); }} className={btnGhost}>
                    <X size={16} /> Cancelar
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-6 text-center text-gray-400">
            <Bell size={36} className="mx-auto mb-2 opacity-30" />
            <p className="font-semibold">Panel de notificaciones</p>
            <p className="text-sm mt-1">Crea una notificación arriba para enviarla a los usuarios según sede y tipo de pase.</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// CONSTANTES GLOBALES DEL MAPA
// ════════════════════════════════════════════════════════════
// COMPONENTE PRINCIPAL
// ════════════════════════════════════════════════════════════
function MapaStandsAdmin({ expositores, sedeActiva, flash, loadExpositores }) {
  const sede = (sedeActiva || "mexico").toLowerCase();
  const categorias = CATEGORIAS_POR_SEDE[sede] || CATEGORIAS_POR_SEDE.mexico;

  const [gridCols,      setGridCols]      = useState(46);
  const [gridFilas,     setGridFilas]     = useState(22);
  const [standAColocar, setStandAColocar] = useState(null);
  const [hoverCell,     setHoverCell]     = useState(null); // preview de celdas
  const [savingId,      setSavingId]      = useState(null);
  const [zoom,          setZoom]          = useState(1);
  const [savingConfig,  setSavingConfig]  = useState(false);

  // Cargar config del grid al montar
  useEffect(() => {
    const lsKey = `mapa_config_${sede}`;
    // 1. Intentar desde localStorage (instantáneo)
    try {
      const cached = JSON.parse(localStorage.getItem(lsKey) || 'null');
      if (cached?.grid_cols) { setGridCols(cached.grid_cols); setGridFilas(cached.grid_filas); }
    } catch {}
    // 2. Cargar desde DB (autoritativo)
    API.get(`/expositores/mapa-config/${sede}`)
      .then(r => {
        if (r.data?.config?.grid_cols) {
          setGridCols(r.data.config.grid_cols);
          setGridFilas(r.data.config.grid_filas || 22);
          localStorage.setItem(lsKey, JSON.stringify(r.data.config));
        }
      })
      .catch(() => {});
  }, [sede]);

  // Guardar config en DB + localStorage
  const guardarConfig = async (cols, filas) => {
    const lsKey = `mapa_config_${sede}`;
    localStorage.setItem(lsKey, JSON.stringify({ grid_cols: cols, grid_filas: filas }));
    setSavingConfig(true);
    try {
      await API.put(`/expositores/mapa-config/${sede}`, { grid_cols: cols, grid_filas: filas, edicion: 2026 });
    } catch { /* silencioso — localStorage ya guardó */ }
    finally { setSavingConfig(false); }
  };

  // Construir mapa de posiciones
  const gridMap = {};
  expositores.forEach(e => {
    if (e.grid_col != null && e.grid_fila != null) {
      const w = e.ancho_celdas || 1;
      const h = e.alto_celdas  || 1;
      for (let dc = 0; dc < w; dc++) {
        for (let df = 0; df < h; df++) {
          const key = `${e.grid_col + dc}-${e.grid_fila + df}`;
          gridMap[key] = { expo: e, isOrigin: dc === 0 && df === 0 };
        }
      }
    }
  });

  const sinPosicion  = expositores.filter(e => e.grid_col == null);
  const conPosicion  = expositores.filter(e => e.grid_col != null);

  // Calcula las celdas que ocuparía el stand en (col,fila) y si puede colocarse
  const getPreviewCells = (col, fila) => {
    if (!standAColocar) return { cells: new Set(), canPlace: true };
    const cat   = categorias.find(c => c.key === (standAColocar.categoria||"").toLowerCase());
    const w     = cat?.celdas_ancho || 1;
    const h     = cat?.celdas_alto  || 1;
    const cells = new Set();
    let canPlace = true;
    for (let dc = 0; dc < w; dc++) {
      for (let df = 0; df < h; df++) {
        const key = `${col+dc}-${fila+df}`;
        cells.add(key);
        if (gridMap[key]) canPlace = false;        // celda ocupada
        if (col+dc > gridCols || fila+df > gridFilas) canPlace = false; // fuera del grid
      }
    }
    return { cells, canPlace };
  };

  const preview = hoverCell ? getPreviewCells(hoverCell.col, hoverCell.fila) : null;

  // Cambiar estado
  const cambiarEstado = async (expo, nuevoEstado) => {
    setSavingId(expo.id);
    try {
      await API.patch(`/expositores/${expo.id}/estado`, { estado_stand: nuevoEstado });
      flash(`✅ ${expo.nombre}: ${ESTADOS_STAND[nuevoEstado]?.label}`);
      await loadExpositores();
    } catch (err) {
      flash(err.response?.data?.error || "Error al cambiar estado", true);
    } finally { setSavingId(null); }
  };

  // Asignar posición en grid — celda vacía clickeada
  const handleCeldaClick = async (col, fila) => {
    if (!standAColocar) return;
    const cat     = categorias.find(c => c.key === (standAColocar.categoria||"").toLowerCase());
    const ancho   = cat?.celdas_ancho || 1;
    const alto    = cat?.celdas_alto  || 1;
    // Verificar que todas las celdas que ocupará están libres
    for (let dc = 0; dc < ancho; dc++) {
      for (let df = 0; df < alto; df++) {
        if (gridMap[`${col+dc}-${fila+df}`]) {
          flash(`⚠️ Celda (${col+dc},${fila+df}) está ocupada. Elige otra posición.`, true);
          return;
        }
        if (col+dc > gridCols || fila+df > gridFilas) {
          flash("⚠️ El stand no cabe (se sale del área). Elige otra posición.", true);
          return;
        }
      }
    }
    try {
      await API.patch(`/expositores/${standAColocar.id}/posicion`, {
        grid_col: col, grid_fila: fila,
        ancho_celdas: ancho, alto_celdas: alto,
      });
      flash(`✅ ${standAColocar.nombre} → (${col},${fila}) — ${ancho}×${alto} celdas`);
      setStandAColocar(null);
      setHoverCell(null);
      await loadExpositores();
    } catch { flash("Error al posicionar", true); }
  };

  // Quitar posición
  const quitarPosicion = async (expo) => {
    try {
      await API.patch(`/expositores/${expo.id}/posicion`, { grid_col: null, grid_fila: null });
      flash(`Posición de ${expo.nombre} eliminada`);
      await loadExpositores();
    } catch { flash("Error", true); }
  };

  const inputCls = "px-3 py-1.5 text-sm border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 dark:text-white";

  return (
    <div className="space-y-6">

      {/* Referencia de categorías para esta sede */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5">
        <h3 className="font-bold text-gray-900 dark:text-white mb-3 text-sm uppercase tracking-wide">
          Tipos de stand — {sede.charAt(0).toUpperCase() + sede.slice(1)}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {categorias.map(cat => (
            <div key={cat.key} className="rounded-xl p-3 border-2 text-center"
              style={{ backgroundColor: cat.color + "18", borderColor: cat.color }}>
              <p className="font-bold text-xs" style={{ color: cat.color }}>{cat.label}</p>
              <p className="text-xs text-gray-500 mt-0.5">{cat.ancho_m}×{cat.alto_m} m</p>
              <p className="text-xs text-gray-400">{cat.celdas_ancho}×{cat.celdas_alto} celdas</p>
            </div>
          ))}
        </div>
      </div>

      {/* Config del grid */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 p-5">
        <h3 className="font-bold text-gray-900 dark:text-white mb-4 text-sm">
          Dimensiones del área ({sede})
        </h3>
        <div className="flex flex-wrap gap-4 items-end">
          <div>
            <label className="text-xs font-semibold text-gray-500 mb-1 block">Columnas</label>
            <input type="number" min="10" max="80" value={gridCols}
              onChange={e => setGridCols(Math.max(10, parseInt(e.target.value)||46))}
              onBlur={e => guardarConfig(Math.max(10, parseInt(e.target.value)||46), gridFilas)}
              className={inputCls} style={{ width: 90 }} />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 mb-1 block">Filas</label>
            <input type="number" min="5" max="50" value={gridFilas}
              onChange={e => setGridFilas(Math.max(5, parseInt(e.target.value)||22))}
              onBlur={e => guardarConfig(gridCols, Math.max(5, parseInt(e.target.value)||22))}
              className={inputCls} style={{ width: 90 }} />
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setZoom(z => Math.max(z-0.1, 0.3))}
              className="px-2 py-1.5 text-sm border border-gray-200 rounded-lg hover:bg-gray-50">−</button>
            <span className="text-xs text-gray-500 w-12 text-center">{Math.round(zoom*100)}%</span>
            <button onClick={() => setZoom(z => Math.min(z+0.1, 2))}
              className="px-2 py-1.5 text-sm border border-gray-200 rounded-lg hover:bg-gray-50">+</button>
            <button onClick={() => setZoom(1)}
              className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg text-gray-400 hover:bg-gray-50">↺</button>
          </div>
          <button
            onClick={() => guardarConfig(gridCols, gridFilas)}
            disabled={savingConfig}
            className="flex items-center gap-1.5 text-xs px-3 py-1.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 disabled:opacity-50 transition">
            {savingConfig ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
            {savingConfig ? "Guardando..." : "Guardar dimensiones"}
          </button>
          <p className="text-xs text-gray-400">
            {conPosicion.length}/{expositores.length} posicionados
          </p>
        </div>
      </div>

      {/* Stands sin posición */}
      {sinPosicion.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-700 rounded-2xl p-4">
          <p className="text-sm font-bold text-amber-700 dark:text-amber-300 mb-3">
            ⚠️ {sinPosicion.length} expositor(es) sin posición
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {sinPosicion.map(expo => {
              const cat = categorias.find(c => c.key === (expo.categoria||"").toLowerCase());
              return (
                <div key={expo.id}
                  className="flex items-center gap-2 bg-white dark:bg-gray-800 rounded-xl p-2.5 border border-amber-100">
                  {expo.logo_url && (
                    <img src={expo.logo_url} className="w-7 h-7 object-contain rounded"
                      onError={e => e.target.style.display='none'} />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-gray-900 dark:text-white truncate">{expo.nombre}</p>
                    <p className="text-xs text-gray-400">
                      {expo.stand ? `Stand ${expo.stand}` : "Sin #"}
                      {cat ? ` · ${cat.label} (${cat.ancho_m}×${cat.alto_m}m)` : ""}
                    </p>
                  </div>
                  <button
                    onClick={() => setStandAColocar(standAColocar?.id === expo.id ? null : expo)}
                    className={`shrink-0 text-xs px-2.5 py-1.5 rounded-xl font-semibold transition ${
                      standAColocar?.id === expo.id
                        ? "bg-blue-600 text-white"
                        : "bg-blue-50 text-blue-600 border border-blue-200 hover:bg-blue-100"
                    }`}
                  >
                    {standAColocar?.id === expo.id ? "✕ Cancelar" : "📌 Ubicar"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Banner modo ubicar */}
      {standAColocar && (() => {
        const cat      = categorias.find(ct => ct.key === (standAColocar.categoria||"").toLowerCase());
        const canPlace = preview?.canPlace ?? true;
        return (
          <div className={`border-2 rounded-2xl p-4 flex items-center gap-3 transition-colors ${
            canPlace ? "bg-blue-50 dark:bg-blue-900/10 border-blue-400" : "bg-red-50 dark:bg-red-900/10 border-red-400"
          }`}>
            <div className={`w-9 h-9 rounded-full flex items-center justify-center text-white text-lg shrink-0 ${canPlace ? "bg-blue-600" : "bg-red-500"}`}>
              {canPlace ? "📌" : "⛔"}
            </div>
            <div className="flex-1">
              <p className={`text-sm font-bold ${canPlace ? "text-blue-700 dark:text-blue-300" : "text-red-700 dark:text-red-300"}`}>
                Posicionando: <strong>{standAColocar.nombre}</strong>
                {cat && <span className="font-normal text-xs ml-2 opacity-70">({cat.label} · {cat.ancho_m}×{cat.alto_m}m · {cat.celdas_ancho}×{cat.celdas_alto} celdas)</span>}
              </p>
              <p className={`text-xs mt-0.5 ${canPlace ? "text-blue-500" : "text-red-500"}`}>
                {canPlace
                  ? "Mueve el cursor sobre el grid — el área azul muestra dónde quedará. Clic para confirmar."
                  : "Posición no válida: celdas ocupadas o fuera del área. Mueve el cursor."}
              </p>
            </div>
            <button onClick={() => { setStandAColocar(null); setHoverCell(null); }}
              className="text-gray-400 hover:text-gray-600 shrink-0">
              <X size={20} />
            </button>
          </div>
        );
      })()}

      {/* Grid visual */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex flex-wrap items-center gap-3">
          <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">
            Plano {gridCols}×{gridFilas} — {sede}
          </span>
          <div className="flex flex-wrap gap-2">
            {Object.entries(ESTADOS_STAND).map(([k, v]) => (
              <span key={k} className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-semibold"
                style={{ backgroundColor: v.bg, color: v.text, border: `1px solid ${v.border}` }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: v.dot }} />
                {v.label}
              </span>
            ))}
          </div>
        </div>
        <div className="overflow-auto p-3 bg-gray-50 dark:bg-gray-900" style={{ maxHeight: 520 }}>
          <div style={{
            display: "grid",
            gridTemplateColumns: `repeat(${gridCols}, minmax(40px, 1fr))`,
            gap: "2px",
            transform: `scale(${zoom})`,
            transformOrigin: "top left",
            transition: "transform 0.2s",
            width: `${100/zoom}%`,
          }}>
            {Array.from({ length: gridCols * gridFilas }, (_, i) => {
              const col  = (i % gridCols) + 1;
              const fila = Math.floor(i / gridCols) + 1;
              const cell = gridMap[`${col}-${fila}`];
              if (cell && !cell.isOrigin) return null;

              const expo   = cell?.expo;
              const estado = ESTADOS_STAND[expo?.estado_stand || "libre"];
              const ancho  = expo?.ancho_celdas || 1;
              const alto   = expo?.alto_celdas  || 1;
              const isSaving = expo && savingId === expo.id;

              const inPreview = preview?.cells.has(`${col}-${fila}`);
              const canDrop   = preview?.canPlace ?? true;

              return (
                <div
                  key={`${col}-${fila}`}
                  onClick={() => !expo && handleCeldaClick(col, fila)}
                  onMouseEnter={() => standAColocar && !expo && setHoverCell({ col, fila })}
                  onMouseLeave={() => standAColocar && setHoverCell(null)}
                  title={expo
                    ? `${expo.nombre}${expo.stand ? " · Stand "+expo.stand : ""} · ${estado.label}`
                    : standAColocar
                      ? `Colocar aquí: columna ${col}, fila ${fila}`
                      : `Vacío (${col},${fila})`
                  }
                  style={{
                    gridColumn: `span ${ancho}`,
                    gridRow:    `span ${alto}`,
                    backgroundColor: inPreview
                      ? (canDrop ? "#dbeafe" : "#fee2e2")
                      : expo ? estado.bg : (standAColocar ? "#f0f9ff" : "#ffffff"),
                    border: `2px solid ${inPreview
                      ? (canDrop ? "#2563eb" : "#dc2626")
                      : expo ? estado.border : (standAColocar ? "#bae6fd" : "#e2e8f0")}`,
                    outline: inPreview && canDrop ? "2px solid #93c5fd" : "none",
                    outlineOffset: 1,
                    borderRadius: "5px",
                    minHeight: "48px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "3px",
                    cursor: expo ? "default" : (standAColocar ? "crosshair" : "default"),
                    position: "relative",
                    transition: "all 0.1s",
                  }}
                >
                  {expo ? (
                    <>
                      {expo.logo_url
                        ? <img src={expo.logo_url} style={{ width:26, height:26 }}
                            className="object-contain"
                            onError={e => e.target.style.display='none'} />
                        : <Building2 size={14} style={{ color: estado.text }} />
                      }
                      <span style={{
                        fontSize: "0.5rem", fontWeight: 700, color: estado.text,
                        textAlign: "center", lineHeight: 1.2, marginTop: 2,
                        maxWidth: "100%", overflow: "hidden",
                      }}>
                        {expo.stand || expo.nombre?.split(" ")[0]}
                      </span>
                      {/* Dot de estado */}
                      <span style={{
                        position:"absolute", top:3, right:3,
                        width:8, height:8, borderRadius:"50%",
                        backgroundColor: estado.dot,
                      }} />
                      {/* Hover: acciones */}
                      <div className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity"
                        style={{ backgroundColor:"rgba(255,255,255,0.95)", borderRadius:"3px",
                          display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:3, padding:4 }}>
                        {isSaving
                          ? <Loader2 size={12} className="animate-spin text-blue-500" />
                          : <>
                              <span style={{ fontSize:"0.5rem", fontWeight:700, color:"#1e293b", textAlign:"center", lineHeight:1.2 }}>
                                {expo.nombre?.split(" ").slice(0,2).join(" ")}
                              </span>
                              <span style={{ fontSize:"0.44rem", color:"#64748b" }}>
                                {expo.stand ? `Stand ${expo.stand}` : ""}
                              </span>
                              <div style={{ display:"flex", gap:3 }}>
                                {Object.entries(ESTADOS_STAND).map(([k, v]) => (
                                  <button key={k}
                                    onClick={e => { e.stopPropagation(); cambiarEstado(expo, k); }}
                                    title={v.label}
                                    style={{
                                      width:12, height:12, borderRadius:"50%",
                                      backgroundColor: v.bg,
                                      border: `2px solid ${v.border}`,
                                      cursor: "pointer",
                                      outline: (expo.estado_stand||"libre") === k ? "2px solid #2563eb" : "none",
                                      outlineOffset: 1,
                                    }}
                                  />
                                ))}
                              </div>
                              <button
                                onClick={e => { e.stopPropagation(); quitarPosicion(expo); }}
                                style={{ fontSize:"0.42rem", color:"#ef4444", cursor:"pointer", marginTop:1 }}>
                                quitar posición
                              </button>
                            </>
                        }
                      </div>
                    </>
                  ) : (
                    <span style={{ fontSize: "0.42rem", color: standAColocar ? "#0ea5e9" : "#d1d5db" }}>
                      {standAColocar ? "＋" : `${col},${fila}`}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tabla de gestión de estados */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
            Estado de todos los stands ({expositores.length})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                {["Empresa", "Stand", "Categoría", "Posición en grid", "Estado actual", "Cambiar a"].map(h => (
                  <th key={h} className="px-3 py-2 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
              {expositores.map(expo => {
                const estado = ESTADOS_STAND[expo.estado_stand || "libre"];
                const cat    = categorias.find(c => c.key === (expo.categoria||"").toLowerCase());
                return (
                  <tr key={expo.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/40 transition">
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        {expo.logo_url && (
                          <img src={expo.logo_url} className="w-6 h-6 object-contain rounded"
                            onError={e => e.target.style.display='none'} />
                        )}
                        <span className="text-sm font-medium text-gray-900 dark:text-white">{expo.nombre}</span>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-sm text-gray-500">{expo.stand || "—"}</td>
                    <td className="px-3 py-2.5">
                      {cat
                        ? <span className="text-xs px-2 py-0.5 rounded-full font-semibold"
                            style={{ backgroundColor: cat.color + "18", color: cat.color, border:`1px solid ${cat.color}` }}>
                            {cat.label}
                          </span>
                        : <span className="text-xs text-gray-400">{expo.categoria || "—"}</span>
                      }
                    </td>
                    <td className="px-3 py-2.5 text-sm">
                      {expo.grid_col != null
                        ? <code className="text-xs bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded">
                            ({expo.grid_col},{expo.grid_fila})
                            {(expo.ancho_celdas > 1 || expo.alto_celdas > 1)
                              ? ` ${expo.ancho_celdas}×${expo.alto_celdas}`
                              : ""}
                          </code>
                        : <button
                            onClick={() => setStandAColocar(standAColocar?.id === expo.id ? null : expo)}
                            className="text-xs text-amber-600 hover:text-amber-700 font-medium underline">
                            Asignar →
                          </button>
                      }
                    </td>
                    <td className="px-3 py-2.5">
                      <span className="px-2.5 py-1 rounded-full text-xs font-bold"
                        style={{ backgroundColor:estado.bg, color:estado.text, border:`1px solid ${estado.border}` }}>
                        {estado.label}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <select
                        value={expo.estado_stand || "libre"}
                        onChange={e => cambiarEstado(expo, e.target.value)}
                        disabled={savingId === expo.id}
                        className="px-2 py-1 text-xs border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 dark:text-white disabled:opacity-50"
                      >
                        {Object.entries(ESTADOS_STAND).map(([k, v]) => (
                          <option key={k} value={k}>{v.label}</option>
                        ))}
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}